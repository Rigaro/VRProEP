﻿//======= Copyright (c) Melbourne Robotics Lab, All rights reserved. ===============

namespace VRProEP.GameEngineCore
{
    /// <summary>
    /// Structure to save user data for Feedback Characterization.
    /// </summary>
    public abstract class FeedbackCharacterization
    {
    }

}
